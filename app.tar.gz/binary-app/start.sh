#!/bin/bash

php -S 0.0.0.0:8080 -t /tmp/app
